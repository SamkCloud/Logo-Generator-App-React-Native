import React, { useState } from "react";
import {
  Text,
  View,
  StyleSheet,
  TextInput,
  ScrollView,
  TouchableOpacity,
  ImageBackground,
  Image,
} from "react-native";

import { GradientCard, LineChart } from "react-native-gradient-card-view";
import AppLoading from "expo-app-loading";
import { LinearGradient } from "expo-linear-gradient";

import { useFonts, Barriecito_400Regular } from "@expo-google-fonts/barriecito";
import { Barrio_400Regular } from "@expo-google-fonts/barrio";
import { Akronim_400Regular } from "@expo-google-fonts/akronim";
import { Megrim_400Regular } from "@expo-google-fonts/megrim";
import { Audiowide_400Regular } from "@expo-google-fonts/audiowide";
import { HerrVonMuellerhoff_400Regular } from "@expo-google-fonts/herr-von-muellerhoff";
import { MajorMonoDisplay_400Regular } from "@expo-google-fonts/major-mono-display";

import { Card } from "react-native-paper";
import { Icon } from "react-native-elements";
import Entypo from "react-native-vector-icons/Entypo";
import Ionicons from "react-native-vector-icons/Ionicons";

import ColorDots from "./components/ColorsDots";
import TextInputBlock from "./components/TextInputBlock";

const LogoGenerator = (props) => {
  const [companyName, setCompanyName] = useState("");
  const [subText, setSubtext] = useState("");

  const [color, setColor] = useState(["white", "white"]);
  const [modalVisible, setModalVisible] = useState(false);

  let [fontsLoaded] = useFonts({
    Akronim_400Regular,
    Barriecito_400Regular,
    Barrio_400Regular,
    Audiowide_400Regular,
    HerrVonMuellerhoff_400Regular,
    Megrim_400Regular,
    MajorMonoDisplay_400Regular,
  });

  if (!fontsLoaded) {
    return <AppLoading />;
  }

  return (
    <View
      style={
        ([styles.container],
        {
          backgroundColor: "#f5f5f5",
          flex: 1,
          padding: 20,
          marginTop: 30,
        })
      }
    >
      <View
        style={{
          justifyContent: "center",
          alignContent: "center",
          height: 50,
          width: "100%",
          marginBottom: 5,
        }}
      >
        <Text
          style={{ fontFamily: "MajorMonoDisplay_400Regular", fontSize: 30 }}
        >
          Logo Generator
        </Text>
      </View>
      <View style={{ flexDirection: "column", justifyContent: "flex-start" }}>
        <TextInputBlock
          Cname={companyName}
          CSetName={setCompanyName}
          Sname={subText}
          SSetName={setSubtext}
        />
      <Text
        style={{ fontFamily: "Audiowide_400Regular", fontSize: 12, marginTop:10 }}
        >
        Select the themes Below. In these Circles ↓↓↓
      </Text>
      <ColorDots selectedColor={setColor} />
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        showsHorizontalScrollIndicator={true}
        // horizontal={true}
        style={{ justifyContent: "flex-start", alignItems: "center" }}
      >
        <View style={{ borderBottomColor: "black", borderBottomWidth: 2 }} />

        <Card style={[styles.cards]}>
          <LinearGradient
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            colors={color}
            style={[styles.gradientStyle, styles.gradientCardCover]}
          >
            <View>
              <Entypo name="aircraft" size={30} color="white" />
            </View>
            <View>
              <Text style={[styles.cardOneHead]}>{companyName}</Text>
              <Text style={[styles.cardOnesub]}>{subText}</Text>
            </View>
          </LinearGradient>
        </Card>

        <Card style={[styles.cards]}>
          <LinearGradient
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            colors={color}
            style={[styles.gradientStyle, styles.gradientCardCover]}
          >
            <ImageBackground
              source={require("./assets/buildings.png")}
              style={{ width: "100%", height: "100%" }}
            >
              <View
                style={{
                  position: "absolute",
                  top: 0,
                  left: 0,
                  right: 0,
                  bottom: 0,
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <Text style={[styles.cardTwoHead]}>{companyName}</Text>
                <Text style={[styles.cardTwosub]}>{subText}</Text>
              </View>
            </ImageBackground>
          </LinearGradient>
        </Card>

        <Card style={[styles.cards]}>
          <LinearGradient
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            colors={color}
            style={[styles.gradientStyle, styles.gradientCardCover]}
          >
            <View
              style={{
                justifyContent: "center",
                flexDirection: "column",
                flex: 1,
              }}
            >
              <Text style={[styles.cardThreeHead]}>{companyName}</Text>
              <Text style={[styles.cardThreesub]}>{subText}</Text>
            </View>
          </LinearGradient>
        </Card>

        <Card style={[styles.cards]}>
          <LinearGradient
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            colors={color}
            style={[styles.gradientStyle, styles.gradientCardCover]}
          >
            <ImageBackground
              source={require("./assets/questioMarks.png")}
              style={{ width: "100%", height: "100%", position: "absolute" }}
            >
              <View
                style={{
                  justifyContent: "center",
                  alignItems: "center",
                  alignContent: "center",
                  flex: 1,
                }}
              >
                <Text style={[styles.cardFourHead]}>{companyName}</Text>
                <Text style={[styles.cardFoursub]}>{subText}</Text>
              </View>
            </ImageBackground>
          </LinearGradient>
        </Card>

        <Card style={[styles.cards]}>
          <LinearGradient
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            colors={color}
            style={[styles.gradientStyle, styles.gradientCardCover]}
          >
            <ImageBackground
              source={require("./assets/buildings.png")}
              style={{ width: "100%", height: "100%", resizeMode: "cover" }}
            >
              <View
                style={{
                  position: "absolute",
                  top: 0,
                  left: 0,
                  right: 0,
                  bottom: 0,
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <Text style={[styles.cardFiveHead]}>{companyName}</Text>
                <Text style={[styles.cardFivesub]}>{subText}</Text>
              </View>
            </ImageBackground>
          </LinearGradient>
        </Card>

        <View style={{ borderBottomColor: "black", borderBottomWidth: 2 }} />
      </ScrollView>
    </View>
  );
};
export default LogoGenerator;

const styles = StyleSheet.create({
  container: {
    justifyContent: "center",
    padding: 24,
  },
  cards: {
    height: 180,
    width: 300,
    margin: 10,
    borderRadius: 15,
    alignItems: "center",
    overflow: "hidden",
  },
  gradientCardCover: {
    flex: 1,
    height: 200,
    width: 300,
    overflow: "hidden",
    justifyContent: "center",
    alignContent: "center",
    alignItems: "center",
    flexDirection: "column",
  },
  cardOneHead: {
    fontFamily: "Barrio_400Regular",
    fontSize: 30,
    color: "white",
  },
  cardTwoHead: {
    fontFamily: "Megrim_400Regular",
    fontSize: 30,
    color: "white",
  },
  cardThreeHead: {
    fontFamily: "HerrVonMuellerhoff_400Regular",
    fontSize: 40,
    color: "white",
    textAlign: "left",
  },
  cardFourHead: {
    fontFamily: "Akronim_400Regular",
    fontSize: 30,
    color: "white",
    textAlign: "left",
    padding: 10,
  },
  cardFiveHead: {
    fontFamily: "Audiowide_400Regular",
    fontSize: 30,
    color: "white",
  },
  cardOnesub: {
    fontFamily: "Barrio_400Regular",
    fontSize: 20,
    marginBottom: 20,
  },
  cardTwosub: {
    fontFamily: "Megrim_400Regular",
    fontSize: 20,
    marginBottom: 20,
    color: "white",
  },
  cardThreesub: {
    fontFamily: "HerrVonMuellerhoff_400Regular",
    fontSize: 30,
    marginBottom: 20,
    color: "white",
    textAlign: "center",
  },
  cardFoursub: {
    fontFamily: "Akronim_400Regular",
    fontSize: 25,
    marginBottom: 20,
    color: "white",
    textAlign: "right",
  },
  cardFivesub: {
    fontFamily: "Audiowide_400Regular",
    fontSize: 18,
    marginBottom: 20,
    color: "white",
  },
});
