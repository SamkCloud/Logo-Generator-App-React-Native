import React from "react";
import {
  Text,
  View,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity,
  TextInput,
} from "react-native";
import { Card } from "react-native-paper";

const TextInputBlock = (props) => {
  return (
    <View style={styles.textInputBlockView}>
      <TextInput
        style={styles.input}
        onChangeText={props.CSetName}
        value={props.Cname}
        placeholder="Enter Company Name"
        keyboardType="text"
      />
      <TextInput
        style={styles.input}
        onChangeText={props.SSetName}
        value={props.SName}
        placeholder="Enter subtext"
        keyboardType="text"
      />
    </View>
  );
};
export default TextInputBlock;

const styles = StyleSheet.create({
  input: {
    backgroundColor: "#ffff",
    width: "100%",
    height: 40,
    borderRadius: 15,
    padding: 8,
    marginBottom: 8,
    elevation: 4,
  },
  textInputBlockView: {
    marginBottom: 0,
    flexDirection: "column",
    justifyContent: "center",
  },
});
