import React from "react";
import {
  Text,
  View,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity,
} from "react-native";
import { Card } from "react-native-paper";

const ColorDots = (props) => {
  return (
    <ScrollView
      showsVerticalScrollIndicator={false}
      showsHorizontalScrollIndicator={false}
      horizontal={true}
      style={{
        height: 100,
        width: "100%",
        alignItems: "center",
      }}
    >
      <TouchableOpacity
        onPress={() => props.selectedColor(["#092B9C", "#8C60F1"])}
      >
        <Card
          style={[
            styles.card,
            {
              backgroundColor: "blue",
            },
          ]}
        />
      </TouchableOpacity>
      <TouchableOpacity
        onPress={() => props.selectedColor(["#A91310", "#BE1C17"])}
      >
        <Card
          style={[
            styles.card,
            {
              backgroundColor: "#A91310",
            },
          ]}
        />
      </TouchableOpacity>
      <TouchableOpacity
        onPress={() => props.selectedColor(["#991A67", "#FF1DCE"])}
      >
        <Card
          style={[
            styles.card,
            {
              backgroundColor: "#E61CB4", //Pink
            },
          ]}
        />
      </TouchableOpacity>
      <TouchableOpacity
        onPress={() => props.selectedColor(["#FFDF00", "#EDC903"])}
      >
        <Card
          style={[
            styles.card,
            {
              backgroundColor: "yellow",
            },
          ]}
        />
      </TouchableOpacity>
      <TouchableOpacity
        onPress={() => props.selectedColor(["#1E9086", "#75CA9A"])}
      >
        <Card
          style={[
            styles.card,
            {
              backgroundColor: "teal",
            },
          ]}
        />
      </TouchableOpacity>
      <TouchableOpacity onPress={() => props.selectedColor(["pink", "white"])}>
        <Card
          style={[
            styles.card,
            {
              backgroundColor: "lightpink",
            },
          ]}
        />
      </TouchableOpacity>
      <TouchableOpacity onPress={() => props.selectedColor(["black", "black"])}>
        <Card
          style={[
            styles.card,
            {
              backgroundColor: "black",
            },
          ]}
        />
      </TouchableOpacity>
    </ScrollView>
  );
};
export default ColorDots;

const styles = StyleSheet.create({
  card: {
    borderRadius: 100,
    height: 60,
    width: 60,
    elevation: 10,
    margin: 5,
  },
});
