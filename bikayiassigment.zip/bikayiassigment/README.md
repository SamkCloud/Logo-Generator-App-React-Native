# Expo app
Built BY shubham

Open the `App.js`. You can preview the changes directly on your phone or tablet by scanning the **QR code** or use the iOS or Android emulators.
you can run the app on Android phone by Installing Expo Apk from play store.

In project you can Create logo 
This is prototype version of app you can say 1.0 Built on 15th may 2022

how to run the app

its easy just write the name of ComPany Name you wanted and a subtext you wanted on The logo
example : Comapny name : { Fake Comapny}
        : subtext : {since 2022}



